import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  loadGrid=new Subject<boolean>();

  constructor(
    private http:HttpClient,

    ) { }

    getBookedTicketDetails():Observable<any>{
      return this.http.get(`${environment.apiUrl}moviebooking/getBookedTickets`);
    }

    updateTicketStatus(movieId:any,theatreName:any,status:any):Observable<any>{
 return this.http.post(`${environment.apiUrl}moviebooking/`+movieId+`/update/`+theatreName+`/`+status+``,"");
    } 

    deleteMovie(movieName:any,movieId:any):Observable<any>{
      return this.http.delete(`${environment.apiUrl}moviebooking/movie/`+movieName+`/delete/`+movieId+``);
    }
}
