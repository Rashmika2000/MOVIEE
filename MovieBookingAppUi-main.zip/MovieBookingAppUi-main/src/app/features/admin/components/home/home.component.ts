import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { SpinnerService } from 'src/app/shared/services/spinner.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { EditMovieStatusComponent } from '../edit-movie-status/edit-movie-status.component';
import { DeleteMovieComponent } from '../delete-movie/delete-movie.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  data: any=[];
  bsModalRef: any;

  constructor(
    private adminService:AdminService,
    private spinnerService:SpinnerService,
    private modalService: BsModalService
    ) { }

  ngOnInit(): void {
    this.adminService.loadGrid.subscribe(res=>{
      if(res){
        this.loadMovies();
      }
    })

    this.loadMovies();
  
  }

  loadMovies(){
    this.adminService.getBookedTicketDetails().subscribe(res=>{
      console.log(res)
      this.data=res.data;
    })
  }

  editMovie(movie:any){
    const config = {
      backdrop: true,
      
    };
    const val: any = {
      movie: movie
    };
    this.bsModalRef = this.modalService.show(
      EditMovieStatusComponent,
      Object.assign(
        config,
        {},
        { class: 'modal-dialog-centered modal-lg', initialState: val }
      )
    );
  }

  deleteMovie(movie:any){
    const config = {
      backdrop: true,
      
    };
    const val: any = {
      movie: movie
    };
    this.bsModalRef = this.modalService.show(
      DeleteMovieComponent,
      Object.assign(
        config,
        {},
        { class: 'modal-dialog-centered ', initialState: val }
      )
    );
  }

}
