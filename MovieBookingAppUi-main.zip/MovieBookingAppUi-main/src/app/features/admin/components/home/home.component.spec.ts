import { SpinnerService } from "src/app/shared/services/spinner.service";
import { BsModalService, ModalModule } from "ngx-bootstrap/modal";
import { TestBed, getTestBed } from "@angular/core/testing";
import { HomeComponent } from "./home.component";
import { Component } from "@angular/core";
import { of } from "rxjs";
import { AdminService } from "../../services/admin.service";

describe('Admin Home Components',()=>{
   let data:any;
   let mockAdminService:any;
   let mockSpinnerService:SpinnerService;
   let component:HomeComponent
   beforeEach(()=>{
   data=[
      {
      "movieName":"Test Movie",
      "theatreName":"This is test movie",
      "bookedSeat":50,
      "availableSeat":100
   },
   {
    "movieName":"# Idiot",
    "theatreName":"This is comedy movie",
    "bookedSeat":40,
    "availableSeat":110
 }
]

   mockAdminService=jasmine.createSpyObj(['getBookedTicketDetails','updateTicketStatus','deleteMovie']);
   mockSpinnerService=jasmine.createSpyObj(['setSpinner','getSpinner','show','hide']);
   TestBed.configureTestingModule({
      imports:[
         ModalModule.forRoot()
      ],
    providers:[
      
      HomeComponent,
      {
         provide:AdminService,
         useValue:mockAdminService
      },
      {
         provide:SpinnerService,
         useValue:mockSpinnerService
      }
    ]
   });
 
   component=TestBed.inject(HomeComponent);
   });


   describe("loadMovies()",()=>{
      it("initially the data should be empty",()=>{
         expect(component.data.length).toBe(0);
      })

      it("It should return two movies",()=>{
         mockAdminService.getBookedTicketDetails.and.returnValue(of({data:data}));
         component.loadMovies();
         expect(component.data.length).toBe(2);
      })

      it("getAllMovie() method in movie service should be called only once",()=>{
         mockAdminService.getBookedTicketDetails.and.returnValue(of({data:data}));
         component.loadMovies();
         expect(mockAdminService.getBookedTicketDetails).toHaveBeenCalledTimes(1);
      })
   });
});