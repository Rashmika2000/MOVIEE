import { Component, Input, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AdminService } from '../../services/admin.service';
import { SnackbarService } from 'src/app/shared/services/snackbar.service';
import { SpinnerService } from 'src/app/shared/services/spinner.service';

@Component({
  selector: 'app-delete-movie',
  templateUrl: './delete-movie.component.html',
  styleUrls: ['./delete-movie.component.scss']
})
export class DeleteMovieComponent implements OnInit {
  @Input() movie:any;
  constructor(
     public modalService:BsModalService,
     private adminService:AdminService,
     private snackbar:SnackbarService,
     private spinner:SpinnerService
  ) { }

  ngOnInit(): void {
  }

  onClickYes(){
   
  this.adminService.deleteMovie(this.movie.movieName,this.movie.movieId).subscribe(res=>{
    this.adminService.loadGrid.next(true);
   
    this.modalService.hide();
   this.snackbar.open(res.message,"Close");
  })
  }
}
