import { Component, Input, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { SnackbarService } from 'src/app/shared/services/snackbar.service';
import { SpinnerService } from 'src/app/shared/services/spinner.service';

@Component({
  selector: 'app-edit-movie-status',
  templateUrl: './edit-movie-status.component.html',
  styleUrls: ['./edit-movie-status.component.scss']
})
export class EditMovieStatusComponent implements OnInit {
@Input() movie:any;
  constructor(
    private adminService:AdminService,
    private snackbar:SnackbarService,
    private spinner:SpinnerService
    ) { }

  ngOnInit(): void {
  }

  onChangeStatus(status:any,theatreName:any){
   
  this.adminService.updateTicketStatus(this.movie.movieId,theatreName,status).subscribe(res=>{
    this.adminService.loadGrid.next(true);
  
  this.snackbar.open(res.message,"Ok")
  })
  }

}
