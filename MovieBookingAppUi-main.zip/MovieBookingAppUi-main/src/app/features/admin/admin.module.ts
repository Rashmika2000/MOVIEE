import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { HomeComponent } from './components/home/home.component';
import { DeleteMovieComponent } from './components/delete-movie/delete-movie.component';
import { EditMovieStatusComponent } from './components/edit-movie-status/edit-movie-status.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalModule } from 'ngx-bootstrap/modal';


@NgModule({
  declarations: [
    HomeComponent,
    DeleteMovieComponent,
    EditMovieStatusComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    SharedModule,
    ModalModule.forRoot(),
  ]
})
export class AdminModule { }
