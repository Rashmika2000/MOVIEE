import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LoginModel } from '../models/LoginModel';
import { User } from '../models/User';
import { ApiResponse } from 'src/app/shared/models/ApiResponse';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private router: Router,
    private http: HttpClient
  ) {
   
  }


  login(loginModel: LoginModel) {
    return this.http.post<ApiResponse<User>>(`${environment.apiUrl}moviebooking/login`, loginModel)
      .pipe(map(res => {
        // store user details and jwt token in local storage to keep user logged in between page refreshes
        localStorage.setItem('user', JSON.stringify(res.data));
        return res;
      }));
  }


  register(user: User) {
    return this.http.post(`${environment.apiUrl}moviebooking/register`, user);
  }

  forgotPassWord(loginId:string,data:any):Observable<ApiResponse<string>>{
    return this.http.post<ApiResponse<string>>(`${environment.apiUrl}moviebooking/`+loginId+`/forgot`, data);
  }

  isLoggedIn(){
    var data=JSON.parse(localStorage.getItem('user') as string);

    if (data!=null) {
      this.router.navigate(['dashboard']);
    }
  }

  getAuthToken(){
    var data=JSON.parse(localStorage.getItem('user') as string);
    if (data!=null) {
      return data.token;
    }
    else{
      return null;
    }
  }

  isAdmin():boolean{
    var data=JSON.parse(localStorage.getItem('user') as string);
    if (data!=null && data.role==='Admin') {
      return true;
    }
    else{
      return false;
    }
  }

  logout(){
    localStorage.removeItem('user');
    this.router.navigate(['user/login']);
  }

  getUserData(){
    var data=JSON.parse(localStorage.getItem('user') as string);
    if (data!=null) {
      return data;
    }
    else{
      return null;
    }
  }
  
}
