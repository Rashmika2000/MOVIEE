import { Component, OnInit } from '@angular/core';
import { FormBuilder, UntypedFormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs';
import { SnackbarService } from 'src/app/shared/services/snackbar.service';
import { SpinnerService } from 'src/app/shared/services/spinner.service';
import { UserService } from '../../services/user.service';
import { ValidationService } from 'src/app/shared/services/validation.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  signupForm: any;
  formErrors:any = {};

  validationMessages = {
    'firstName': {
      'required': 'First name is required.',
      'pattern': 'First name is not valid.',
      'length':'First name must be atleast 2 character long'
    },
    'lastName': {
      'required': 'Last name is required.',
      'pattern': 'Last name is not valid.'
    },
    'loginId':{
      'required': 'Login Id is required.',
    },
    'mobile':{
      'required': 'Mobile number is required.',
      'pattern': 'Please provide valid mobile number'
    },
    'email': {
      'required': 'Email is required.',
      'pattern': 'Please provide valid Email ID'
    },
    'password': {
      'required': 'Password is required.',
      'pattern': 'Password should be 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character'
    },
    'confirmPassword': {
      'required': 'Confirm Password is required.',
      'mismatch': 'Password and Confirm Password do not match'
    }
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private _validation: ValidationService,
    private userService:UserService,
    private route: ActivatedRoute,
    private spinnerService:SpinnerService,
    private snackbar:SnackbarService
    ) { }

  ngOnInit(): void {
    this.signupForm = this.fb.group({
      firstName: ['',[Validators.required,Validators.pattern(this._validation.regex.name)]],
      lastName: ['',[Validators.required,Validators.pattern(this._validation.regex.name)]],
      loginId: ['',],
      mobile: ['',[Validators.required,Validators.pattern(this._validation.regex.mobile)]],
      email: ['',[Validators.required,Validators.pattern(this._validation.regex.email)]],
      password: ['',[Validators.required,Validators.pattern(this._validation.regex.password)]],
      confirmPassword: ['',[Validators.required]]
    },
    {
      validator: [this._validation.matchConfirmItems('password', 'confirmPassword'),
      this._validation.moreThanTwoChar('firstName')],
      
    },
    );

    this.signupForm.valueChanges.subscribe(
      () => {
        this.logValidationErrors()
      }
    );
  }

  logValidationErrors() {
    this.formErrors = this._validation.getValidationErrors(this.signupForm, this.validationMessages);
  }

  onSubmitSignupForm() {
    if (this.signupForm.invalid) {
      return;
  }
  this.spinnerService.show();
  this.userService.register(this.signupForm.value)
  .pipe(first())
  .subscribe({
      next: () => {
        this.spinnerService.hide();
        this.snackbar.open("Registration successful","");
          //this.alertService.success('Registration successful', { keepAfterRouteChange: true });
          this.router.navigate(['user/login']);
      },
      error: error => {
          //this.alertService.error(error);
         // this.loading = false;
         this.spinnerService.hide();
      }
  });
  }

}
