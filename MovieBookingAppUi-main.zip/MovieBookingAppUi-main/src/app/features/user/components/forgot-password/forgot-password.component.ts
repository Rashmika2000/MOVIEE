import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { SnackbarService } from 'src/app/shared/services/snackbar.service';
import { BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  cnfPassword:any;
  password:any;
  loginId:any;
  errorMsg: string='';
  constructor(
    private userService:UserService,
    private snackbar:SnackbarService,
    private modalService: BsModalService
    ) { }

  ngOnInit(): void {
  }

  onClickSubmit(){
    console.log(this.loginId)
    if(this.loginId==="" ||this.loginId===null || this.loginId==undefined){
      this.errorMsg="Login id is required."
      return;
    }

    if(this.password==="" ||this.password===null || this.password==undefined){
      this.errorMsg="Password is required."
      return;
    }

    if(this.cnfPassword==="" ||this.cnfPassword===null || this.cnfPassword===undefined){
      this.errorMsg="Confirm password is required."
      return;
    }

    if(this.password!==this.cnfPassword){
      this.errorMsg="Password and confirm password doesn't match."
      return;
    }

    this.userService.forgotPassWord(this.loginId,{password:this.password,confirmPassword:this.cnfPassword})
    .subscribe(res=>{
  this.modalService.hide();
  this.snackbar.open(res.message,"Close");
    })

  }

}
