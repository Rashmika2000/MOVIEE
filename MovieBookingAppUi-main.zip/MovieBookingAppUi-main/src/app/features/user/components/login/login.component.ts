import { Component, OnInit } from '@angular/core';
import { FormBuilder, UntypedFormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs';
import { SpinnerService } from 'src/app/shared/services/spinner.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { UserService } from '../../services/user.service';
import { SnackbarService } from 'src/app/shared/services/snackbar.service';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { MovieService } from 'src/app/features/dashboard/services/movie.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: any;
  formErrors:any = {};
  hide:boolean=true;
  validationMessages = {
    'loginId': {
      'required': 'Login Id is required.'
    },
    'password': {
      'required': 'Password is required.',
      'pattern': 'Invalid password'
    }
  };
  bsModalRef: any;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private _validation: ValidationService,
    private userService:UserService,
    private route: ActivatedRoute,
    private spinnerService:SpinnerService,
    private snackbar:SnackbarService,
    private movieService:MovieService,
    private modalService: BsModalService,
    
    ) { }

  ngOnInit(): void {
    this.userService.isLoggedIn();
    this.loginForm = this.fb.group({
      loginId: ['',[Validators.required,]],
      password: ['',[Validators.required,Validators.pattern(this._validation.regex.password)]] });

      this.loginForm.valueChanges.subscribe(
        () => {
          this.logValidationErrors()
        }
      );
  }

  logValidationErrors() {
    this.formErrors = this._validation.getValidationErrors(this.loginForm, this.validationMessages);
  }

  onSubmitLoginForm(){
    if (this.loginForm.invalid) {
      return;
  }
this.spinnerService.show();
  this.userService.login(this.loginForm.value)
  .pipe(first())
  .subscribe({
      next: (res) => {
        console.log(res)
          // get return url from query parameters or default to home page
          // const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
          this.spinnerService.hide();
         if(res.data.role==='Admin'){
          this.router.navigate(["admin"]);
         }
         else{
          this.router.navigate(["dashboard"]);
         }
         
          
      },
      error: (error) => {
          this.snackbar.open(error.error.message,"Close");
         
         this.spinnerService.hide();
      }
  });
  
  }

  openForgotPasswordPopup(){
    const config = {
      backdrop: true,
      
    };

    this.bsModalRef = this.modalService.show(
      ForgotPasswordComponent,
      Object.assign(
        config,
        {},
        { class: 'modal-dialog-centered modal-lg'}
      )
    );
  }

}
