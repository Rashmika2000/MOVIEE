export class LoginModel{
    userId?:string;
    password?:string;
  }