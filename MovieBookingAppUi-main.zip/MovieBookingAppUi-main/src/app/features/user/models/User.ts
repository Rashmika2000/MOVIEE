export class User{
    firstName?:string;
    lastName?:string;
    email?:string;
    role?:string;
    token?:string;

}