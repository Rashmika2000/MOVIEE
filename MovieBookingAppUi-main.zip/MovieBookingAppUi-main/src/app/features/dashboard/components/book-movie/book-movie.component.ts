import { Component, Input, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { SpinnerService } from 'src/app/shared/services/spinner.service';
import { MovieService } from '../../services/movie.service';
import { SnackbarService } from 'src/app/shared/services/snackbar.service';

@Component({
  selector: 'app-book-movie',
  templateUrl: './book-movie.component.html',
  styleUrls: ['./book-movie.component.scss']
})
export class BookMovieComponent implements OnInit {
@Input() movie: any;
selectedTheatre:any;
addError:any;
noOfTicket:any;
  constructor(
    private movieService:MovieService,
    private spinnerService:SpinnerService,
    private modalService: BsModalService,
    private snackbar:SnackbarService
  ) { }

  ngOnInit(): void {
  }

  BookTicket(movie:any,index:any){
   
    let data={
      "movieId": movie.id,
      "theatreName": movie.theatreDetails[index].theatreName,
      "numberOfTicket": this.noOfTicket,
      "seatNumber": [
        ""
      ]
    }
    if(this.noOfTicket<=0 || this.noOfTicket===null || this.noOfTicket===undefined){
       this.addError="Please enter no of tickets."
      return;
    }
    if(movie.theatreDetails[index].seats<this.noOfTicket){
      this.addError="Please enter valid number of tickets."
      return;
    }
    data.seatNumber=[];
    for(var i=0;i<this.noOfTicket;i++){
      data.seatNumber.push('A'+(i+1));
    }
    this.spinnerService.show();
   this.movieService.bookMovie(movie.movieName,data).subscribe(res=>{
    this.spinnerService.hide();
    this.modalService.hide();
   this.snackbar.open(res.message,"Close");
   },
   error=>{
    this.spinnerService.hide();
    this.modalService.hide();
   })
  }

}
