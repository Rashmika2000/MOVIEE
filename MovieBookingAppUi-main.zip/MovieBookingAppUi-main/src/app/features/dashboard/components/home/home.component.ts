import { Component, OnInit } from '@angular/core';
import { MovieService } from '../../services/movie.service';
import { SpinnerService } from 'src/app/shared/services/spinner.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BookMovieComponent } from '../book-movie/book-movie.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  movieList: any=[];
  emptyMovieList: boolean=false;
  bsModalRef: any;

  constructor(
    private movieService:MovieService,
    private spinnerService:SpinnerService,
    private modalService: BsModalService
    ) { }

  ngOnInit(): void {
   this.getAllMovies();
  }

  SearchMovie(event:any){
    this.emptyMovieList=false;
    if(event.target.value==='' || event.target.value===undefined || event.target.value===null){
      this.getAllMovies();
    }
    else{
      this.movieService.searchMovie(event.target.value).subscribe(res=>{
        this.movieList=res.data;
       
        if(res.data.length<=0){
          this.emptyMovieList=true;
        }
       })
    }

  }

  getAllMovies(){
    this.spinnerService.show();
    this.movieService.getAllMovie().subscribe(res=>{
      this.movieList=res.data;
      this.spinnerService.hide();
    })
  }

  OnClickBook(data:any){
    const config = {
      backdrop: true,
      
    };
    const val: any = {
      movie: data
    };
    this.bsModalRef = this.modalService.show(
      BookMovieComponent,
      Object.assign(
        config,
        {},
        { class: 'modal-dialog-centered modal-lg', initialState: val }
      )
    );
  }

}
