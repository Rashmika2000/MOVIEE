import { SpinnerService } from "src/app/shared/services/spinner.service";
import { MovieService } from "../../services/movie.service";
import { BsModalService, ModalModule } from "ngx-bootstrap/modal";
import { TestBed, getTestBed } from "@angular/core/testing";
import { HomeComponent } from "./home.component";
import { Component } from "@angular/core";
import { of } from "rxjs";

describe('Movie Home Components',()=>{
   let MovieList:any;
   let mockMovieService:any;
   let mockSpinnerService:SpinnerService;
   let mockModalService:BsModalService;
   let component:HomeComponent
   beforeEach(()=>{
   MovieList=[
      {
      "movieName":"Test Movie",
      "movieDescription":"This is test movie",
      "Rating":"4"
   },
   {
      "movieName":"Bahubali",
      "movieDescription":"This is historical movie",
      "Rating":"3"
   }
]

   mockMovieService=jasmine.createSpyObj(['getAllMovie','searchMovie','bookMovie']);
   mockSpinnerService=jasmine.createSpyObj(['setSpinner','getSpinner','show','hide']);
   TestBed.configureTestingModule({
      imports:[
         ModalModule.forRoot()
      ],
    providers:[
      
      HomeComponent,
      {
         provide:MovieService,
         useValue:mockMovieService
      },
      {
         provide:SpinnerService,
         useValue:mockSpinnerService
      }
    ]
   });
 
   component=TestBed.inject(HomeComponent);
   });


   describe("getAllMovies()",()=>{
      it("initially the movie list should be empty",()=>{
         expect(component.movieList.length).toBe(0);
      })

      it("It should return two movies",()=>{
         mockMovieService.getAllMovie.and.returnValue(of({data:MovieList}));
         component.getAllMovies();
         expect(component.movieList.length).toBe(2);
      })

      it("getAllMovie() method in movie service should be called only once",()=>{
         mockMovieService.getAllMovie.and.returnValue(of({data:MovieList}));
         component.getAllMovies();
         expect(mockMovieService.getAllMovie).toHaveBeenCalledTimes(1);
      })
   });

   describe("seachMovie()",()=>{
      it("should return two movie",()=>{
         mockMovieService.searchMovie.and.returnValue(of({data:MovieList}));
         component.SearchMovie({target:{value:'bahu'}});
         expect(component.movieList.length).toBe(2);
      });
      
      it("seachMovie() method in movie service should be called only once",()=>{
         mockMovieService.searchMovie.and.returnValue(of({data:MovieList}));
         component.SearchMovie({target:{value:'bahu'}});
         expect(mockMovieService.searchMovie).toHaveBeenCalledTimes(1);
      })
   })

  

});