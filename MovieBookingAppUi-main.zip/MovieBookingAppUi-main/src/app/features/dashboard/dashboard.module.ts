import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { HomeComponent } from './components/home/home.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BookMovieComponent } from './components/book-movie/book-movie.component';

@NgModule({
  declarations: [
    HomeComponent,
    BookMovieComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule,
    ModalModule.forRoot(),
  ]
})
export class DashboardModule { }
