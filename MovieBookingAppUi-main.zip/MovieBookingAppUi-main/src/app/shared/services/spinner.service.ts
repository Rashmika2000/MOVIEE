import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {
  private spinner: boolean = false;
  
  constructor() { }

  setSpinner(loading: boolean) {
    this.spinner = loading;
  }

  show() {
    this.spinner = true;
  }

  hide() {
    this.spinner = false;
  }

  getSpinner(): boolean {
    return this.spinner;
  }
}
