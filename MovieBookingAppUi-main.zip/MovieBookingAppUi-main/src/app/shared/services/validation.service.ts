import { Injectable } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  constructor() { }

  public regex = {
    email: '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$',
    password:'^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,15}$',
    name:"^[a-zA-Z]+(?:(?:|['_\. ])([a-zA-Z]*(\.\s)?[a-zA-Z])+)*$",
    mobile:"^[6-9][0-9]{9}$"
  }

  getValidationErrors(group: UntypedFormGroup, validationMessages: any): any {
    var formErrors:any = {};

    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);

      formErrors[key] = '';
      if (abstractControl && !abstractControl.valid &&
        (abstractControl.touched || abstractControl.dirty)) {

        const messages = validationMessages[key];

        for (const errorKey in abstractControl.errors) {
          if (errorKey) {
            formErrors[key] += messages[errorKey] + ' ';
          }
        }
      }

      if (abstractControl instanceof UntypedFormGroup) {
        let groupError = this.getValidationErrors(abstractControl, validationMessages);
        formErrors = { ...formErrors, ...groupError }
      }

    });
    return formErrors
  }

  matchConfirmItems(controlName: string, confirmControlName: string) {
    return (formGroup: UntypedFormGroup):any => {
      const control = formGroup.controls[controlName];
      const confirmControl = formGroup.controls[confirmControlName];

      if (!control || !confirmControl) {
        return null;
      }

      if (confirmControl.errors && !confirmControl.errors['mismatch']) {
        return null;
      }

      if (control.value !== confirmControl.value) {
        confirmControl.setErrors({ mismatch: true });
      } else {
        confirmControl.setErrors(null);
      }
    }
  }

  moreThanTwoChar(controlName: string) {
    return (formGroup: UntypedFormGroup):any => {
      const control = formGroup.controls[controlName];

      if (control.errors && !control.errors['length']) {
        return null;
      }

      if (control.value.length<=2) {
        control.setErrors({ length: true });
      } else {
        control.setErrors(null);
      }
    }
  }

}
