import { Component } from '@angular/core';
import { UserService } from './features/user/services/user.service';
import { NavigationEnd, NavigationStart, Route, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'MovieBookingAppUi';
  user: any;
  showHead: boolean=false;

  constructor(private userService:UserService,private router:Router){
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        if (event.url === '/user/login' || event.url=='/user/register') {
          this.showHead= true;
        } else {
          this.showHead= false;
        }
      }
    });
  }
  
  ngOnInit(): void {
    this.user=this.userService.getUserData();
  }
  logout(): void{
   this.userService.logout();
  }
}
