import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './helpers/auth.guard';

const routes: Routes = [
  {
    path:'',
    redirectTo:'dashboard',
    pathMatch:'full'
     },
     {
       path: 'user',
       loadChildren: () => import('./features/user/user.module').then(m => m.UserModule)
     },
     {
      path: 'dashboard',
      canActivate:[AuthGuard],
      loadChildren: () => import('./features/dashboard/dashboard.module').then(m => m.DashboardModule)
    },
    {
      path: 'admin',
      canActivate:[AuthGuard],
      loadChildren: () => import('./features/admin/admin.module').then(m => m.AdminModule)
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
