import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { SnackbarService } from '../shared/services/snackbar.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { UserService } from '../features/user/services/user.service';

@Injectable()
export class InterceptorInterceptor implements HttpInterceptor {

  constructor(
    private userService:UserService,
    private router:Router,
    private snackbar:SnackbarService,
    private modalService:BsModalService,
    private spinnerService:SpinnerService
  ) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {  
    const token = this.userService.getAuthToken();

   if (token) {
     // If we have a token, we set it to the header
     request = request.clone({
        setHeaders: {Authorization: `Bearer ${token}`}
     });
  }

  return next.handle(request).pipe(
  	catchError((err) => {
   	 if (err instanceof HttpErrorResponse) {
      this.spinnerService.hide();
      if(err.status===400){
        this.snackbar.open(err.error.message,"Close")
      }
      if (err.status === 403) {
        this.snackbar.open("You are not authorize to access this page.","Close")
      }
       	 if (err.status === 401) {
          this.modalService.hide();
          this.snackbar.open("Session expire","Close")
          localStorage.removeItem('user')
       	 this.router.navigate(['user/login']);
     	}
       if (err.status === 500) {
        this.snackbar.open("Internal Server Error.","Close")
     }
     if (err.status === 0){
    this.snackbar.open("Server is down, Try again later !","Close")
      }
 	 }
  	return throwError(err);
	})
   )
  }
}
