export const environment = {
  production: true,
  apiUrl:'https://moviebookingapi20230622105805.azurewebsites.net/api/v1.0/'
};
