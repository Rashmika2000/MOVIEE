﻿using MovieBooking.Dto;
using MovieBooking.Model;
using MovieBookingApi.Model;

namespace MovieBooking.Service
{
    public interface IAuthService
    {
        ResponseDto<UserDto> Register(UserModel registerModel);
        ResponseDto<UserDto> Login(LoginModel loginModel);
        ResponseDto<UserDto> ForgotPassword(string loginId, string password);
    }
}
