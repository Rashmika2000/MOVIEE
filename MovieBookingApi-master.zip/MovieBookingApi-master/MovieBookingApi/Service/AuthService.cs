﻿using Microsoft.IdentityModel.Tokens;
using MovieBooking.Dto;
using MovieBooking.Model;
using MovieBooking.Repository;
using MovieBookingApi.Model;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MovieBooking.Service
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository _authRepository;
        private readonly IConfiguration _config;
        public AuthService(IAuthRepository authRepository, IConfiguration config)
        {
            _authRepository = authRepository;
            _config = config;
        }
        public ResponseDto<UserDto> ForgotPassword(string loginId,string password)
        {
            return _authRepository.ForgotPassword(loginId,password);
        }

        public ResponseDto<UserDto> Login(LoginModel loginModel)
        {
            ResponseDto<UserDto> responseDto = _authRepository.Login(loginModel);

            if (responseDto.isSuccess)
            {
                responseDto.Data.Token = GenerateToken(responseDto.Data);
            }
            return responseDto;
        }

        public ResponseDto<UserDto> Register(UserModel registerModel)
        {
            registerModel.Password = BCrypt.Net.BCrypt.HashPassword(registerModel.Password);
           
            if (registerModel.Email.Contains("@admin.com"))
            {
                registerModel.Role = "Admin";
            }
            else
            {
                registerModel.Role = "User";
            }

            return _authRepository.Register(registerModel);

        }
        public string GenerateToken(UserDto user)
        {

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim>
              {
                  new Claim(ClaimTypes.Email,user.Email),
                  new Claim(ClaimTypes.Role, user.Role)
              };

            var token = new JwtSecurityToken(
              issuer: _config["Jwt:Issuer"],
              audience: _config["Jwt:Issuer"], 
              claims: claims,
              expires: DateTime.Now.AddDays(365),
              signingCredentials: credentials);



            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
