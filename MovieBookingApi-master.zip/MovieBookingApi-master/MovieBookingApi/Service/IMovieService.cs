﻿using MovieBookingApi.Model;

namespace MovieBookingApi.Service
{
    public interface IMovieService
    {
        List<MovieModel> GetAllMovie();
        List<MovieModel> SearchMovieByName(string movieName);
        bool DeleteMovie(string Id);
    }
}
