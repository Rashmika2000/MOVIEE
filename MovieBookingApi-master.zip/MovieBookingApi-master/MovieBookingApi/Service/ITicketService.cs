﻿using MovieBooking.Dto;
using MovieBookingApi.Dto;
using MovieBookingApi.Model;

namespace MovieBookingApi.Service
{
    public interface ITicketService
    {
        ResponseDto<string> BookTicket(string userEmail,TicketModel ticketModel);
        ResponseDto<List<BookedMovieTicketDto>> GetBookedTickets();
        bool UpdateTicketStatus(string movieId, string theatreName, string status);
    }
}
