﻿using MovieBookingApi.Model;
using MovieBookingApi.Repository;

namespace MovieBookingApi.Service
{
    public class MovieService : IMovieService
    {
        private readonly IMovieRepository _movieRepository;

        public MovieService(IMovieRepository movieRepository)
        {
            _movieRepository = movieRepository;
        }

        public bool DeleteMovie(string Id)
        {
           return _movieRepository.DeleteMovie(Id);
        }

        public List<MovieModel> GetAllMovie()
        {
           return _movieRepository.GetAllMovie();
        }

        public List<MovieModel> SearchMovieByName(string movieName)
        {
           return _movieRepository.SearchMovieByName(movieName);
        }
    }
}
