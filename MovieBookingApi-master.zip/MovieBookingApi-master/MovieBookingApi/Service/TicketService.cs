﻿using MovieBooking.Dto;
using MovieBookingApi.Dto;
using MovieBookingApi.Model;
using MovieBookingApi.Repository;

namespace MovieBookingApi.Service
{
    public class TicketService : ITicketService
    {
        private readonly ITicketRepository _ticketRepository;

        public TicketService(ITicketRepository ticketRepository)
        {
           _ticketRepository = ticketRepository;
        }

        public ResponseDto<string> BookTicket(string userEmail,TicketModel ticketModel)
        {
           return _ticketRepository.BookTicket( userEmail, ticketModel);
        }

        public ResponseDto<List<BookedMovieTicketDto>> GetBookedTickets()
        {
           return _ticketRepository.GetBookedTickets();
        }

        public bool UpdateTicketStatus(string movieId, string theatreName, string status)
        {
            return _ticketRepository.UpdateTicketStatus(movieId, theatreName, status);
        }
    }
}
