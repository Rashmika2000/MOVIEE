﻿using MovieBookingApi.Model;

namespace MovieBookingApi.Repository
{
    public interface IMovieRepository
    {
        List<MovieModel> GetAllMovie();
        List<MovieModel> SearchMovieByName(string movieName);
        bool DeleteMovie(string Id);
    }
}
