﻿using MovieBooking.Dto;
using MovieBooking.Model;
using MovieBookingApi.Model;

namespace MovieBooking.Repository
{
    public interface IAuthRepository
    {
        ResponseDto<UserDto> Register(UserModel registerModel);
        ResponseDto<UserDto> Login(LoginModel loginModel);
        ResponseDto<UserDto> ForgotPassword(string loginId, string password);
    }
}
