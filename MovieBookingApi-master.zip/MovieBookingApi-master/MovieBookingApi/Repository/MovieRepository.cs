﻿using MongoDB.Bson;
using MongoDB.Driver;
using MovieBooking.Model;
using MovieBookingApi.Database;
using MovieBookingApi.Model;

namespace MovieBookingApi.Repository
{
    public class MovieRepository : IMovieRepository
    {
        private readonly IMongoCollection<MovieModel> _movies;
        public MovieRepository(IDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _movies = database.GetCollection<MovieModel>("Movies");
        }

    

        public bool DeleteMovie(string Id)
        {
            var  movieModel=_movies.Find(x => x.Id == Id).FirstOrDefault();
            if(movieModel != null)
            {
                _movies.DeleteOne(m => m.Id == Id);
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<MovieModel> GetAllMovie()
        {
           return _movies.Find(_ => true).ToList();
        }

        public List<MovieModel> SearchMovieByName(string movieName)
        {
            var filter = Builders<MovieModel>.Filter.Regex("MovieName", new BsonRegularExpression(movieName,"i"));
            List<MovieModel> result = _movies.Find(filter).ToList<MovieModel>();

            return result;
        }
    }
}
