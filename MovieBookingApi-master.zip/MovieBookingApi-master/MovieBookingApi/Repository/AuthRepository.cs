﻿using MongoDB.Driver;
using MovieBooking.Dto;
using MovieBooking.Model;
using MovieBookingApi.Database;
using MovieBookingApi.Model;

namespace MovieBooking.Repository
{
    public class AuthRepository : IAuthRepository
    {
        private readonly IMongoCollection<UserModel> _user;
        public AuthRepository(IDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _user = database.GetCollection<UserModel>("Users");
        }


        public ResponseDto<UserDto> ForgotPassword(string loginId,string  password)
        {
            var user = _user.Find(u => u.LoginId ==loginId).FirstOrDefault();
            if (user == null)
                return new ResponseDto<UserDto> { isSuccess = false, message = "Please enter valid login id ." };
            else
            {
               var filter=Builders<UserModel>.Filter.Eq(u=>u.LoginId,loginId);
                var update=Builders<UserModel>.Update.Set(u=>u.Password, BCrypt.Net.BCrypt.HashPassword(password));
                _user.UpdateOne(filter, update);
                return new ResponseDto<UserDto> { isSuccess = true, message = "Password Successfully Changed." };
            }
        }

        public ResponseDto<UserDto> Login(LoginModel loginModel)
        {
            var user = _user.Find(u => u.LoginId == loginModel.LoginId).FirstOrDefault();

            if (user == null)
                return new ResponseDto<UserDto> { isSuccess = false, message = "Please enter valid login id ." };
            else
            {
                if (!BCrypt.Net.BCrypt.Verify(loginModel.Password, user.Password))
                {
                    return new ResponseDto<UserDto> { isSuccess = false, message = "Incorrect password!" };
                }
                else
                {
                    return new ResponseDto<UserDto> { isSuccess = true, Data = new UserDto { FirstName = user.FirstName, LastName = user.LastName, Email = user.Email, Role = user.Role } };
                }
            }
        }

        public ResponseDto<UserDto> Register(UserModel user)
        {
            var isUserEmailExists = _user.Find<UserModel>(u => u.Email == user.Email).FirstOrDefault<UserModel>();
            if (isUserEmailExists != null)
            {
                return new ResponseDto<UserDto> { isSuccess = false, message = "User with email " + user.Email + " already registered." };
            }

            var isUserLoginIdExists = _user.Find(u => u.LoginId == user.LoginId).FirstOrDefault();
            if (isUserLoginIdExists != null)
            {
                return new ResponseDto<UserDto> { isSuccess = false, message = "User with login id " + user.LoginId + " already registered." };
            }

            _user.InsertOne(user);
            return new ResponseDto<UserDto> { isSuccess = true, message = "Registration Successfull" };
        }
    }
}
