﻿using MongoDB.Driver;
using MovieBooking.Dto;
using MovieBookingApi.Database;
using MovieBookingApi.Dto;
using MovieBookingApi.Model;
using System.Collections.Generic;

namespace MovieBookingApi.Repository
{
    public class TicketRepository : ITicketRepository
    {
        private readonly IMongoCollection<TicketModel> _ticket;
        private readonly IMongoCollection<MovieModel> _movie;
        public TicketRepository(IDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _ticket = database.GetCollection<TicketModel>("Tickets");
            _movie = database.GetCollection<MovieModel>("Movies");
        }

        public ResponseDto<string> BookTicket(string userEmail,TicketModel ticketModel)
        {
            MovieModel movieModel= _movie.Find(m=>m.Id == ticketModel.MovieId).FirstOrDefault();
            if (movieModel == null)
            {
                return new ResponseDto<string> { message = "Movie details not found.", isSuccess = false };
            }
            else
            {
                TheatreModel theatres = movieModel.TheatreDetails.Find(t => t.TheatreName == ticketModel.TheatreName);
                if (theatres == null)
                {
                    return new ResponseDto<string> { message = "Theatre details not found." ,isSuccess=false};
                }
                else
                {
                    int totalBookedTicket = 0;
                    List<TicketModel> ticketModels=_ticket.Find(t=>t.MovieId==ticketModel.MovieId && t.TheatreName==ticketModel.TheatreName).ToList();
                    foreach(TicketModel t in ticketModels)
                    {
                        totalBookedTicket += t.NumberOfTicket;
                    }
                    if (totalBookedTicket >= theatres.Seats)
                    {
                        return new ResponseDto<string> { message = "No seats available.",isSuccess=false };
                    }
                    else
                    {
                        ticketModel.UserId=userEmail;
                        _ticket.InsertOne(ticketModel);
                        return new ResponseDto<string> { message = "Ticket booked successfully.", isSuccess = true };
                    }
                }
            }
           
        }

        public ResponseDto<List<BookedMovieTicketDto>> GetBookedTickets()
        {
            List<MovieModel> movies = _movie.Find(_ => true).ToList();
            List<BookedMovieTicketDto> bookedTicketsDetails=new List<BookedMovieTicketDto>();
            foreach (MovieModel m in movies)
            {
                List<BookedTicketDto> BookTicketDetails = new List<BookedTicketDto>();
                foreach(TheatreModel t in m.TheatreDetails)
                {
                    int totalSeat=t.Seats;
                    int totalBookedTicket=0;
                    List<TicketModel> ticketModels=  _ticket.Find(th=>th.TheatreName==t.TheatreName && th.MovieId==m.Id).ToList();
                    foreach(TicketModel tr in ticketModels)
                    {
                        totalBookedTicket += tr.NumberOfTicket;
                    }
                    BookTicketDetails.Add(new BookedTicketDto { BookedTicket = totalBookedTicket, TheatreName = t.TheatreName, TotalTicket = totalSeat,Status=t.Status });

                }
                bookedTicketsDetails.Add(new BookedMovieTicketDto { TicketDetails = BookTicketDetails, MovieId = m.Id, MovieName = m.MovieName, Thumbnail = m.Thumbnail });
            }

            return new ResponseDto<List<BookedMovieTicketDto>> { Data = bookedTicketsDetails, isSuccess = true };
           
        }

        public bool UpdateTicketStatus(string movieId, string theatreName, string status)
        {
           MovieModel movieModel= _movie.Find(m => m.Id == movieId).FirstOrDefault();
            foreach(TheatreModel th in movieModel.TheatreDetails)
            {
                if (th.TheatreName == theatreName)
                {
                    th.Status = status;
                }
            }
            var filter = Builders<MovieModel>.Filter.Eq(m => m.Id,movieId);
            var update = Builders<MovieModel>.Update.Set(m => m.TheatreDetails, movieModel.TheatreDetails);
            _movie.UpdateOne(filter, update);
            return true;
            
        }
    }
}
