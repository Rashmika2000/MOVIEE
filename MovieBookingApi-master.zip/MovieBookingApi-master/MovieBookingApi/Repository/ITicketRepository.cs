﻿using MovieBooking.Dto;
using MovieBookingApi.Dto;
using MovieBookingApi.Model;

namespace MovieBookingApi.Repository
{
    public interface ITicketRepository
    {
        ResponseDto<string> BookTicket(string userEmail,TicketModel ticketModel);
        ResponseDto<List<BookedMovieTicketDto>> GetBookedTickets();

        bool UpdateTicketStatus(string movieId,string theatreName,string status);
    }
}
