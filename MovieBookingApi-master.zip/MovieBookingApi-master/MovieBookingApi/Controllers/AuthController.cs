﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieBooking.Dto;
using MovieBooking.Model;
using MovieBooking.Service;
using MovieBookingApi.Model;
using System.Net;

namespace MovieBooking.Controllers
{
  
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{v:apiVersion}/moviebooking/")]
    public class AuthController : BaseController
    {
        private readonly IAuthService _authService;
        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(AuthController));
        public AuthController(IAuthService authService)
        {
            this._authService = authService;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody]UserModel registerModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _log4net.Info("Registration initiated!");

                    ResponseDto<UserDto> responseDto = _authService.Register(registerModel);
                    if (responseDto.isSuccess)
                    {
                        return Ok(responseDto);
                    }
                    else
                    {
                        return BadRequest(responseDto);
                    }
                }
                else
                {
                    List<string> errors = new List<string>();
                    foreach (var state in ModelState)
                    {
                        foreach (var error in state.Value.Errors)
                        {
                            errors.Add(error.ErrorMessage);
                            break;
                            
                        }
                    }
                    return BadRequest(new ResponseDto<string> { isSuccess = false, message = errors[0] });

                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }

        }

        [HttpPost("login")]
        public IActionResult Login([FromBody]LoginModel loginModel)
        {
            try
            {
                _log4net.Info("Login initiated!");

                ResponseDto<UserDto> responseDto = _authService.Login(loginModel);
                if (responseDto.isSuccess)
                {
                    return Ok(responseDto);
                }
                else
                {
                    return BadRequest(responseDto);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = ex.Message });
            }

        }

        [HttpPost("{loginId}/forgot")]
        public IActionResult ForgotPassword(string loginId,[FromBody]ForgotPasswordModel forgotPasswordModel)
        {
            try
            {
                ResponseDto<UserDto> responseDto = _authService.ForgotPassword(loginId, forgotPasswordModel.Password);
                if (responseDto.isSuccess){
                    return Ok(responseDto);
                }
                else
                {
                    return BadRequest(responseDto);
                }
               
            }
            catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = ex.Message });
            }
          
        }


    }
}
