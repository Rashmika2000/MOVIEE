﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieBooking.Controllers;
using MovieBooking.Dto;
using MovieBookingApi.Model;
using MovieBookingApi.Service;

namespace MovieBookingApi.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{v:apiVersion}/moviebooking/")]
    public class TicketController : BaseController
    {
        private readonly ITicketService _ticketService;
        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(MovieController));
        public TicketController(ITicketService ticketService)
        {
           _ticketService = ticketService;
        }

        [HttpPost("{movieName}/add")]
        [Authorize(Roles ="User")]
        public IActionResult BookMovbieTicket(string movieName,TicketModel ticketModel)
        {
            _log4net.Info("BookMovbieTicket initiated!");
            try
            {
                ResponseDto<string> responseDto = _ticketService.BookTicket(GetUser(),ticketModel);
                if (responseDto.isSuccess)
                {
                    return Ok(responseDto);
                }
                else
                {
                    return BadRequest(responseDto);
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }
        }

        [HttpGet("getBookedTickets")]
        [Authorize(Roles ="Admin")]
        public IActionResult GetBookedTickets()
        {
            _log4net.Info("GetBookedTickets initiated!");
            try
            {
                return Ok(_ticketService.GetBookedTickets());
            }
            catch(Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }
           
        }

        [HttpPost("{movieId}/update/{theatreName}/{status}")]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateTicketStatus(string movieId,string theatreName, string status)
        {
            _log4net.Info("UpdateTicketStatus initiated!");
            try
            {
               if(_ticketService.UpdateTicketStatus(movieId, theatreName, status))
                {
                    return Ok(new ResponseDto<string>() { isSuccess = true,message="Ticket status successfully updated" }) ;
                }
                return BadRequest(new ResponseDto<string>() { isSuccess = false, message = "Something went wrong." });
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }

        }
    }
}
