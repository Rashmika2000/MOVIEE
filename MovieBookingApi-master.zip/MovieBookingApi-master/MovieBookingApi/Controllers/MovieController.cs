﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MovieBooking.Controllers;
using MovieBooking.Dto;
using MovieBookingApi.Model;
using MovieBookingApi.Service;

namespace MovieBookingApi.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{v:apiVersion}/moviebooking/movie/")]
    public class MovieController : BaseController
    {
        private readonly IMovieService _movieService;
        static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(MovieController));
        public MovieController(IMovieService movieService)
        {
            _movieService = movieService;
        }

        [HttpGet("all")]
        public IActionResult GetAllMovie()
        {
            _log4net.Info("GetAllMovie initiated!");
            try
            {
                return Ok(new ResponseDto<List<MovieModel>> { isSuccess= true ,Data=_movieService.GetAllMovie()});
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }
        }

        [HttpGet("search/{movieName}")]
        public IActionResult SearchMovie(string movieName)
        {
            _log4net.Info("SearchMovie initiated!");
            try
            {
                return Ok(new ResponseDto<List<MovieModel>> { isSuccess = true, Data = _movieService.SearchMovieByName(movieName) });
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }
        }

        [HttpDelete("{movieName}/delete/{movieId}")]
        [Authorize(Roles ="Admin")]
        public IActionResult DeleteMovie(string movieName,string movieId)
        {
            _log4net.Info("DeleteMovie initiated!");
            try
            {
                if (_movieService.DeleteMovie(movieId))
                {
                    return Ok(new ResponseDto<string> { isSuccess = true,message="Movie "+ movieName + " deleted successfully"});
                }
                else
                {
                    return BadRequest(new ResponseDto<string> { isSuccess = false,message="Movie with name "+ movieName + " not found." });
                }
            }
            catch(Exception e) 
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ResponseDto<string> { isSuccess = false, message = "Internal server error!", Data = e.Message });
            }
           
        }
    }
}
