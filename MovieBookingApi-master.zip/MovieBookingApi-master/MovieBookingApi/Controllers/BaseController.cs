﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace MovieBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
        protected string GetUser()
        {
            return User.Claims.First(i => i.Type == ClaimTypes.Email).Value;
        }
    }
}
