﻿namespace MovieBookingApi.Model
{
    public class TheatreModel
    {
        public string TheatreName{ get; set; }
        public string TheatreLocation { get; set; }
        public int Seats { get; set; }
        public string Status { get; set; }
    }
}
