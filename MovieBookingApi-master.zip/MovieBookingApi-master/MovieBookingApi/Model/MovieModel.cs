﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace MovieBookingApi.Model
{
    public class MovieModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public string MovieName { get; set; }
        public string Thumbnail { get; set; }
        public string Description { get; set; }
        public int Rating { get; set; }
        public List<TheatreModel> TheatreDetails { get; set; }
    }
}
