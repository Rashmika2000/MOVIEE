﻿namespace MovieBooking.Model
{
    public class LoginModel
    {
       

        public string LoginId { get; set; }
        public string Password { get; set; }
    }
}
