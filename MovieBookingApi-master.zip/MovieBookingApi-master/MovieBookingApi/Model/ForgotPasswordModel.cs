﻿namespace MovieBookingApi.Model
{
    public class ForgotPasswordModel
    {
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }    
    }
}
