﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Text.Json.Serialization;

namespace MovieBookingApi.Model
{
    public class TicketModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [JsonIgnore]
        public string Id { get; set; }
        public string MovieId { get; set; }
        public string TheatreName { get; set; }
        public int NumberOfTicket { get; set; }
        public string UserId { get; set; }
        public string[] SeatNumber { get; set;}
    
    }
}
