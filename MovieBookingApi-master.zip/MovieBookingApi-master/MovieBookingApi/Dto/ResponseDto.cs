﻿namespace MovieBooking.Dto
{
    public class ResponseDto<T>
    {
        public string message { get; set; }
        public T? Data { get; set; }
        public bool isSuccess { get; set; }
    }
}
