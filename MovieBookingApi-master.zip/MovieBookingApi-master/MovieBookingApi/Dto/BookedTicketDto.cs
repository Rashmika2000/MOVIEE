﻿namespace MovieBookingApi.Dto
{
    public class BookedTicketDto
    {
       public int TotalTicket { get; set; }
        public int BookedTicket { get; set; }
        public string TheatreName { get; set; }
        public string Status { get; set; }
    }
}
