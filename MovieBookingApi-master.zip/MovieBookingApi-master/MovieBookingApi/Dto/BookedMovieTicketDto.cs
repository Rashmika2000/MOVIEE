﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace MovieBookingApi.Dto
{
    public class BookedMovieTicketDto
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string MovieId { get; set; }
        public string Thumbnail { get; set; }
        public string MovieName { get; set; }
        public List<BookedTicketDto> TicketDetails { get; set; }
    }
}
