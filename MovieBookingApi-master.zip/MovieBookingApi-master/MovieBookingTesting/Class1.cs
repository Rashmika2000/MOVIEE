﻿namespace MovieBookingTesting
{
    public class Class1
    {

    }
}