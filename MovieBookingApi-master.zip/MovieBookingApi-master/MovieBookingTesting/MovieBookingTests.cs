﻿using Moq;
using MovieBooking.Dto;
using MovieBooking.Model;
using MovieBooking.Service;
using MovieBookingApi.Model;
using MovieBookingApi.Service;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBookingTesting
{
    [TestFixture]
    class MovieBookingTests
    {
        private Mock<IAuthService> _authService;
        private Mock<IMovieService> _movieService;
        LoginModel loginCred;
        ResponseDto<UserDto> responseDto;
        UserModel userModel;
        List<MovieModel> movielist;
        List<MovieModel> searchMovieList;

        [SetUp]
        public void SetUp()
        {
            _authService = new Mock<IAuthService>();
            _movieService=new Mock<IMovieService> ();
            loginCred = new LoginModel {LoginId ="string", Password="string" };
            userModel = new UserModel();
            responseDto = new ResponseDto<UserDto>
            {
                isSuccess = true,
            };

            movielist = new List<MovieModel>()
            {
             new MovieModel { MovieName = "3 idiot", Description = "this is a comedy movie" },
            new MovieModel { MovieName = "Avengers", Description = "this is a Sci-fi movie" }
        
            };
            searchMovieList = new List<MovieModel>
            {
                 new MovieModel { MovieName = "Avengers", Description = "this is a Sci-fi movie" }
            };
        }
        [Test]
        public void AuthenticateUser_Should_Return_True()
        {
            _authService.Setup(l => l.Login(loginCred)).Returns(responseDto);
            bool user = _authService.Object.Login(loginCred).isSuccess;
            Assert.AreEqual(user,true);
        }
        [Test]
        public void Registration_Should_return_True()
        {
            _authService.Setup(p => p.Register(userModel)).Returns(responseDto);
            bool res = _authService.Object.Register(userModel).isSuccess;
            Assert.AreEqual(true, res);
        }
        [Test]
        public void GetAllMovie_Should_return_List_Of_Movie()
        {
            _movieService.Setup(m => m.GetAllMovie()).Returns(movielist);
            List<MovieModel> res = _movieService.Object.GetAllMovie();
            Assert.AreEqual(2, res.Count());
        }
        [Test]
        public void SearchMovie_Should_return_List_Of_Movie()
        {
            _movieService.Setup(m => m.SearchMovieByName("Avengers")).Returns(searchMovieList);
            List<MovieModel> res = _movieService.Object.SearchMovieByName("Avengers");
            Assert.AreEqual(1, res.Count());
        }
    }
}
